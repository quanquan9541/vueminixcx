xlsx.js
=======

XLSX.js is a JavaScript library for converting the data in base64 XLSX files into JavaScript objects - and back! Please see the below link for more information. If you know of a page that contains useful information about XLSX.js, please contact us so that we can include a link here.
